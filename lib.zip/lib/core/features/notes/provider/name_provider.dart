import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hyperion_core/core.dart' hide Provider;


class NameProvider {
  
}

final nameProvider = Provider<String>((ref){
  return 
});